version of django 4.1.3
execution steps:
create a virtual environment (Preffered Manner we can install directly to out PC but it not a correct way)
How to install virtual environment?
steps

1]Open your cmd and this command  >**pip install virtualenv**
1]Create a folder where your want in your PC
2]Open that folder in VS code or Any IDE(Pycharm)
3]run this **virtualenv yourenvname** (yourenvname YOUR WISH)
4]Run **cd yourenvname**
5]Run **Scripts/activate**
6](yourenvname)C:\Users\your username\your folder\yourenvname> will be the prompt
7]Now install django by using this cmd pip install django==4.1.3
8]Check Django is installed or not by using this cmd  **python -m django --version** this will show django version as 4.1.3 
9]Now Move Your project directory inside your env
10]Then Run this cmd **python manage.py runserver** as a result server is running and the page is opened in default web browser

Any queries Comment here
